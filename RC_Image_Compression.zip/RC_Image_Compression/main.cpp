#include <iostream>
#include <fstream>
#include <vector>
#include <easyzlib.h>

using namespace std;

// Function to read image data from file
vector<char> readImage(const string& filename) {
    ifstream file(filename, ios::binary);
    if (!file) {
        cerr << "Error: Unable to open file " << filename << endl;
        exit(EXIT_FAILURE);
    }

    // Read the entire file into a vector
    vector<char> imageData((istreambuf_iterator<char>(file)), istreambuf_iterator<char>());
    file.close();

    return imageData;
}

// Function to write compressed data to file
void writeCompressedData(const string& filename, const vector<char>& compressedData) {
    ofstream file(filename, ios::binary);
    if (!file) {
        cerr << "Error: Unable to create file " << filename << endl;
        exit(EXIT_FAILURE);
    }

    // Write the compressed data to the file
    file.write(compressedData.data(), compressedData.size());
    file.close();
}

vector<char> decompressData(const vector<char>& compressedData) {
    vector<char> decompressedData;
    long decompressedSize = compressedData.size() * 2; // Start with a buffer twice the size of compressed data
    int result = -1; // Initialize result with a non-zero value to enter the loop
    while (result != 0) {
        decompressedData.resize(decompressedSize);
        result = ezuncompress(reinterpret_cast<unsigned char*>(decompressedData.data()), &decompressedSize, reinterpret_cast<const unsigned char*>(compressedData.data()), compressedData.size());
        if (result == EZ_BUF_ERROR) {
            // Increase buffer size and retry decompression
            decompressedSize *= 2;
        } else if (result != 0) {
            cerr << "Error: Decompression failed with code " << result << endl;
            exit(EXIT_FAILURE);
        }
    }
    // Resize the output buffer to fit the actual decompressed size
    decompressedData.resize(decompressedSize);
    return decompressedData;
}


int main() {
    // Input and output filenames
    string inputFilename = "../data/input_image.jpg";
    string compressedFilename = "../data/compressed_image.zlib";
    string decompressedFilename = "../data/decompressed_image.jpg";

    // Read the input image
    vector<char> imageData = readImage(inputFilename);

    vector<char> compressedData;

    // Compress the image data
    for (int i = 0; i < 1000; ++i) {

        compressedData.resize(EZ_COMPRESSMAXDESTLENGTH(imageData.size()));
        long compressedSize = compressedData.size();
        int result = ezcompress(reinterpret_cast<unsigned char *>(compressedData.data()), &compressedSize,
                                reinterpret_cast<const unsigned char *>(imageData.data()), imageData.size());
        if (result != 0) {
            cerr << "Error: Compression failed with code " << result << endl;
            exit(EXIT_FAILURE);
        }
        compressedData.resize(compressedSize);

        // Write the compressed data to a file
        writeCompressedData(compressedFilename, compressedData);
    }

    // Decompress the compressed data
    vector<char> decompressedData = decompressData(compressedData);

    // Write the decompressed data to a file
    ofstream decompressedFile(decompressedFilename, ios::binary);
    if (!decompressedFile) {
        cerr << "Error: Unable to create file " << decompressedFilename << endl;
        exit(EXIT_FAILURE);
    }
    decompressedFile.write(decompressedData.data(), decompressedData.size());
    decompressedFile.close();

    cout << "Image compression and decompression completed successfully!" << endl;

    return 0;
}
